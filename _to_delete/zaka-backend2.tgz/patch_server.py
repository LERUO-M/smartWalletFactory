import sys
p = sys.argv[1]
s = open(p).read()
def rep(old, new):
    global s
    assert old in s, "missing: " + old[:80]
    s = s.replace(old, new, 1)
rep('''const txRoute   = require("./routes/transactions");''', '''const txRoute   = require("./routes/transactions");
const kycRoute  = require("./routes/kyc");
const smsRoute  = require("./routes/sms");''')
rep('''app.use("/api/tx", txRoute);''', '''app.use("/api/tx", txRoute);
app.use("/api/kyc", kycRoute);   // tiered KYC / ZAKA validation
app.use("/api/sms", smsRoute);   // SMS log, test send, AT delivery reports''')
rep('''      <li><b>GET /api/wallet/:phone</b> – Wallet info for a phone number</li>''', '''      <li><b>GET /api/wallet/:phone</b> – Wallet info for a phone number</li>
      <li><b>GET /api/kyc/:phone</b> – KYC level, limits and usage</li>
      <li><b>POST /api/kyc/:phone/verify</b> – Complete ZAKA validation (merchant / website)</li>
      <li><b>GET /api/sms</b> – Outbound SMS log</li>''')
rep('''    console.warn("   Copy backend/.env.example → backend/.env and fill in values.\\n");
  }''', '''    console.warn("   Copy backend/.env.example → backend/.env and fill in values.\\n");
  }

  const sms = require("./services/smsService");
  if (sms.mode() === "simulated") {
    console.warn("📵  SMS is simulated (set AT_USERNAME + AT_API_KEY to send through Africa's Talking).");
  } else {
    console.log(`📨  SMS via Africa's Talking (${sms.mode()}) from short code ${process.env.SHORT_CODE || "(none – set SHORT_CODE)"}`);
  }
  if (!process.env.ADMIN_API_KEY) {
    console.warn("🔓  ADMIN_API_KEY not set – /api/kyc/*/verify and /api/sms/send are open. Set it before going live.");
  }''')
open(p, "w").write(s)
print("server.js patched")
