import sys
p = sys.argv[1]
s = open(p).read()
def rep(old, new, count=1):
    global s
    assert s.count(old) >= 1, "missing: " + old[:80]
    s = s.replace(old, new, count)

rep('''//   POST /api/tx/send              – send ZAR to another phone
// ─''', '''//   POST /api/tx/send              – send ZAR to another phone (KYC limits apply)
//
// Also:
//   GET  /api/transactions/:phone  – recent transfers in/out
//   /api/kyc/*  (routes/kyc.js)    – tiered KYC / ZAKA validation
//   /api/sms/*  (routes/sms.js)    – SMS log, test send, AT delivery reports
// ─''')

rep('''const { sign, requireAuth }   = require("../lib/jwt");''', '''const { sign, requireAuth }   = require("../lib/jwt");
const kycService      = require("../services/kycService");
const smsService      = require("../services/smsService");
const ficaSync        = require("../services/ficaSync");''')

rep('''      tokenSet:     !!process.env.ZAR_TOKEN_ADDRESS,
    },''', '''      tokenSet:     !!process.env.ZAR_TOKEN_ADDRESS,
      smsSet:       smsService.config().configured,
      shortCodeSet: !!process.env.SHORT_CODE,
      smsMode:      smsService.mode(),           // live | sandbox | simulated
      adminKeySet:  !!process.env.ADMIN_API_KEY,
      ficaSync:     ficaSync.enabled(),
    },''')

rep('''      balance: { raw: rawBal.toString(), formatted },
      deployed,
    });''', '''      balance: { raw: rawBal.toString(), formatted },
      deployed,
      kyc: kycService.getStatus(phone),
    });''')

# /auth/register: optional idNumber → KYC Level 0
rep('''    if (authService.isRegistered(phone)) {
      return res.status(409).json({ error: "A wallet already exists for this phone number" });
    }
''', '''    if (authService.isRegistered(phone)) {
      return res.status(409).json({ error: "A wallet already exists for this phone number" });
    }

    // Optional SA ID number → KYC Level 0 (without it the user can't send yet)
    const idNumber = req.body.idNumber ? String(req.body.idNumber).replace(/\\s+/g, "") : null;
    if (idNumber) {
      if (!kycService.validateSaId(idNumber).ok) {
        return res.status(400).json({ error: "Invalid SA ID number" });
      }
      if (kycService.idInUse(idNumber)) {
        return res.status(409).json({ error: "This ID number is already linked to another phone" });
      }
    }
''')
rep('''    // Derive the counterfactual wallet address (no deploy needed)''', '''    if (idNumber) {
      kycService.setIdNumber(phone, idNumber, "web");
      smsService.sendInBackground(phone, smsService.templates.kycUnlock(), { category: "kyc" });
    }

    // Derive the counterfactual wallet address (no deploy needed)''')
rep('''      balance:       { raw: "0", formatted: "R0.00" },
      deployed:      false,
    });''', '''      balance:       { raw: "0", formatted: "R0.00" },
      deployed:      false,
      kyc:           kycService.getStatus(phone),
    });''')

# /tx/send: limits, transfer record, recipient SMS
rep('''    const recipientPhone = toE164(rawRecipient);
    if (!recipientPhone) {
      return res.status(400).json({ error: "Invalid recipient phone number" });
    }
''', '''    const recipientPhone = toE164(rawRecipient);
    if (!recipientPhone) {
      return res.status(400).json({ error: "Invalid recipient phone number" });
    }
    if (recipientPhone === phone) {
      return res.status(400).json({ error: "You cannot send to yourself" });
    }

    const amountCents = Math.round(Number(amountZAR) * 100);
    if (!(amountCents > 0)) return res.status(400).json({ error: "Invalid amount" });

    // Tiered KYC limits
    const limit = kycService.checkSend(phone, amountCents);
    if (!limit.ok) {
      if (limit.reason !== "no_kyc") {
        smsService.sendInBackground(phone, smsService.templates.kycUnlock(), { category: "kyc" });
      }
      return res.status(403).json({
        error: limit.reason === "no_kyc"
          ? "Add your ID number before sending (POST /api/kyc/:phone/id)"
          : `Over your ${limit.reason} limit (${kycService.limitSummary(limit.status)})`,
        code: limit.reason === "no_kyc" ? "kyc_required" : "limit_exceeded",
        kyc: limit.status,
      });
    }
''')
rep('''    const callData = walletService.encodeZARTransfer(recipientWalletAddress, amountWei);
    const userOpHash = await userOpService.sendUserOperation({
      senderWalletAddress,
      senderPhoneNumber:  phone,
      senderOwnerAddress: ownerAddress,
      senderSigner:       signer,
      callData,
    });

    res.json({ userOpHash, recipientPhone, recipientWalletAddress });''', '''    const transferId = kycService.recordTransfer({
      kind: "transfer", senderPhone: phone, recipientPhone, amountCents, status: "pending",
    });

    let userOpHash;
    try {
      const callData = walletService.encodeZARTransfer(recipientWalletAddress, amountWei);
      userOpHash = await userOpService.sendUserOperation({
        senderWalletAddress,
        senderPhoneNumber:  phone,
        senderOwnerAddress: ownerAddress,
        senderSigner:       signer,
        callData,
      });
    } catch (err) {
      kycService.updateTransfer(transferId, { status: "failed", error: err.message.slice(0, 500) });
      throw err;
    }
    kycService.updateTransfer(transferId, { status: "success", opHash: userOpHash });

    smsService.sendInBackground(
      recipientPhone,
      smsService.templates.received(amountCents, phone),
      { category: "received" }
    );

    res.json({
      userOpHash,
      recipientPhone,
      recipientWalletAddress,
      reference: kycService.transferRef(transferId),
      kyc: kycService.getStatus(phone),
    });''')

rep('''// ── Welcome bonus helper ──''', '''// ── GET /api/transactions/:phone ─────────────────────────────────────────────

router.get("/transactions/:phone", (req, res) => {
  const phone = toE164(decodeURIComponent(req.params.phone));
  if (!phone) return res.status(400).json({ error: "Invalid phone number" });
  const limit = Math.min(100, Number(req.query.limit) || 20);
  res.json({ phoneNumber: phone, transactions: kycService.listTransfers(phone, limit) });
});

// ── Welcome bonus helper ──''')

open(p, "w").write(s)
print("api.js patched")
