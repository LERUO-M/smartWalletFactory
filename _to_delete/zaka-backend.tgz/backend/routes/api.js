// backend/routes/api.js
// ─────────────────────────────────────────────────────────────────────────────
// REST API for the web simulator, merchants and the website.
// These endpoints are NOT part of the USSD gateway protocol.
//
//   GET  /api/health                     liveness + config flags
//   GET  /api/wallet/:phone              balance, KYC, (dev) chain details
//   GET  /api/transactions/:phone        recent transfers in/out
//
//   GET  /api/kyc/tiers                  tier table and limits
//   GET  /api/kyc/:phone                 level, limits, usage
//   POST /api/kyc/:phone/id              { idNumber }                → Level 0   [admin]
//   POST /api/kyc/:phone/verify          { level, method, reference } → Level 1   [admin]
//
//   GET  /api/sms?phone=&sinceId=&limit= outbound SMS log (newest first)
//   POST /api/sms/send                   { to, message }  manual/test SMS        [admin]
//   POST /api/sms/delivery               Africa's Talking delivery report callback
//
// [admin] routes require the header `x-admin-key: <ADMIN_API_KEY>` when
// ADMIN_API_KEY is set in .env (open in local development when it isn't).
// ─────────────────────────────────────────────────────────────────────────────

"use strict";

const express       = require("express");
const router        = express.Router();
const authService   = require("../services/authService");
const walletService = require("../services/walletService");
const kycService    = require("../services/kycService");
const smsService    = require("../services/smsService");
const ficaSync      = require("../services/ficaSync");
const { normalisePhone, isValidPhone } = require("../lib/phone");

/** "/api/x/27821234567" → "+27821234567" (also accepts 0821234567) */
const phoneParam = (p) => {
  const digits = String(p || "").replace(/\D/g, "");
  return digits.startsWith("0") ? normalisePhone(digits) : "+" + digits;
};

function requireAdmin(req, res, next) {
  const key = process.env.ADMIN_API_KEY;
  if (!key) return next();
  if (req.get("x-admin-key") === key) return next();
  return res.status(401).json({ error: "Missing or invalid x-admin-key" });
}

/**
 * GET /api/health
 * Liveness check for ngrok / load-balancer health probes.
 */
router.get("/health", (req, res) => {
  res.json({
    status: "ok",
    time:   new Date().toISOString(),
    env: {
      factorySet:   !!process.env.FACTORY_ADDRESS,
      paymasterSet: !!process.env.PAYMASTER_ADDRESS,
      tokenSet:     !!process.env.ZAR_TOKEN_ADDRESS,
      smsSet:       smsService.config().configured,
      shortCodeSet: !!process.env.SHORT_CODE,
      smsMode:      smsService.mode(),          // live | sandbox | simulated
      adminKeySet:  !!process.env.ADMIN_API_KEY,
      ficaSync:     ficaSync.enabled(),
    },
  });
});

/**
 * GET /api/wallet/:phone
 * Balance and KYC status for a phone number, plus chain details for developers.
 */
router.get("/wallet/:phone", async (req, res) => {
  try {
    const phoneNumber = phoneParam(req.params.phone);

    if (!authService.isRegistered(phoneNumber)) {
      return res.json({ registered: false, phoneNumber });
    }

    const kyc = kycService.getStatus(phoneNumber);
    const ownerAddress  = authService.getOwnerAddress(phoneNumber);
    const walletAddress = await walletService.getOrPredictWalletAddress(ownerAddress, phoneNumber);
    const { raw, formatted } = await walletService.getBalance(walletAddress);
    const deployed           = await walletService.isWalletDeployed(walletAddress);

    res.json({
      registered:    true,
      phoneNumber,
      balance:       { raw: raw.toString(), formatted },
      kyc,
      // developer-only details (never shown to end users)
      ownerAddress,
      walletAddress,
      deployed,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/** GET /api/transactions/:phone?limit=20 */
router.get("/transactions/:phone", (req, res) => {
  const phoneNumber = phoneParam(req.params.phone);
  const limit = Math.min(100, Number(req.query.limit) || 20);
  res.json({ phoneNumber, transactions: kycService.listTransfers(phoneNumber, limit) });
});

// ── KYC ───────────────────────────────────────────────────────────────────────

router.get("/kyc/tiers", (req, res) => {
  res.json({ tiers: Object.values(kycService.getTiers()) });
});

router.get("/kyc/:phone", (req, res) => {
  const phoneNumber = phoneParam(req.params.phone);
  const status = kycService.getStatus(phoneNumber);
  if (!status) return res.status(404).json({ error: "Not registered", phoneNumber });
  res.json({ phoneNumber, ...status });
});

/** Capture an ID number (Level 0) – e.g. from the website's sign-up form */
router.post("/kyc/:phone/id", requireAdmin, (req, res) => {
  const phoneNumber = phoneParam(req.params.phone);
  const result = kycService.setIdNumber(phoneNumber, req.body.idNumber, req.body.method || "web");
  if (!result.ok) {
    const code = result.reason === "not_registered" ? 404 : result.reason === "id_in_use" ? 409 : 400;
    return res.status(code).json({ error: result.reason, detail: result.detail });
  }
  res.json({ phoneNumber, ...result.status });
});

/**
 * Complete ZAKA validation (merchant in-person check or website flow).
 * Body: { level?: 1, method: "merchant" | "web", reference?: string }
 */
router.post("/kyc/:phone/verify", requireAdmin, (req, res) => {
  const phoneNumber = phoneParam(req.params.phone);
  const level = req.body.level === undefined ? 1 : Number(req.body.level);
  const method = ["merchant", "web", "admin"].includes(req.body.method) ? req.body.method : "merchant";
  const result = kycService.setLevel(phoneNumber, level, method, req.body.reference);
  if (!result.ok) {
    const code = result.reason === "not_registered" ? 404 : 400;
    const detail = result.reason === "no_id" ? "User must capture an ID number first (Level 0)" : undefined;
    return res.status(code).json({ error: result.reason, detail });
  }

  if (level >= 1) {
    smsService.sendInBackground(
      phoneNumber,
      smsService.templates.kycComplete(kycService.limitSummary(result.status)),
      { category: "kyc" }
    );
    ficaSync.syncApproval(phoneNumber, true, 0);
  }
  res.json({ phoneNumber, ...result.status });
});

// ── SMS ───────────────────────────────────────────────────────────────────────

router.get("/sms", (req, res) => {
  const phone = req.query.phone ? phoneParam(req.query.phone) : undefined;
  const sinceId = Number(req.query.sinceId) || 0;
  const limit = Math.min(200, Number(req.query.limit) || 50);
  res.json({ mode: smsService.mode(), messages: smsService.list({ phone, sinceId, limit }) });
});

router.post("/sms/send", requireAdmin, async (req, res) => {
  const to = normalisePhone(req.body.to);
  const message = String(req.body.message || "").trim();
  if (!isValidPhone(to) || !message) return res.status(400).json({ error: "to and message are required" });
  const sms = await smsService.send(to, message, { category: "manual" });
  res.status(sms.status === "failed" ? 502 : 200).json(sms);
});

/**
 * Africa's Talking delivery reports. Set this URL in the AT dashboard:
 *   https://<your-host>/api/sms/delivery
 * AT posts application/x-www-form-urlencoded: id, status, phoneNumber, failureReason, ...
 */
router.post("/sms/delivery", (req, res) => {
  smsService.applyDeliveryReport(req.body);
  res.sendStatus(200);
});

module.exports = router;
